module Arel
  module Expression
    include Arel::OrderPredications
  end
end
