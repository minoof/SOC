require 'sprockets/rails/version'
if defined? Rails::Railtie
  require 'sprockets/railtie'
end
