module Sprockets
  module Rails
    VERSION = "2.1.3"
  end
end
