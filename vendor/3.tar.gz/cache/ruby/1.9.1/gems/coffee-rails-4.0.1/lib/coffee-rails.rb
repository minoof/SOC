require 'coffee-script'
require 'coffee/rails/engine'
require 'coffee/rails/template_handler'
require 'coffee/rails/version'
