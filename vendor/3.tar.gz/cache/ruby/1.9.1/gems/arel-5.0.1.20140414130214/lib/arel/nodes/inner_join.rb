module Arel
  module Nodes
    class InnerJoin < Arel::Nodes::Join
    end
  end
end
