# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AlternateConfigProject::Application.config.secret_token = 'aad80c771c1b2b13b67b0b2d03ee3fa8a1d5a8e8dce2e8bc8b382f197927b789afdc9355f8bc7256faf650015d75d8eb541e9ab96a88f0bd63c4bd7552174849'
