module EngineProject
  class ApplicationController < ActionController::Base
  end
end
